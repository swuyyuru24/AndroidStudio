package com.example.orientationphone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SensorEventListener {

    //initialising a handler to update the UI whenever necessary
    public Handler myhandler=new Handler();
    //values to be updated in the UI
    private EditText z_azimuth, x_pitch,y_roll;
    //a button for the corresponding button placed in UI
    private Button resultbutton;

    //Sensor Manager to handle the different sensors being used.
    private SensorManager sensor_manager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor magnetometer;


    //float arrays to store the data from each sensor
    private float acclcords[]=new float[3];
    private float gravitycords[]=new float[3];
    private float magcords[]= new float[3];
    private float gyrocords[]= new float[3];

    //arrays to store the values of rotation matrix and orientation values.
    private float[] acmrotationMatrix = new float[9];
    private float acmorientationValues[] = new float[3];
    private float gyroinitialmatrix[]= new float[9];
    private float gyroorientationvalues[]=new float[3];
    private final float[] deltaRotationVector = new float[4];
    private float[] sensorFusionOrientation=new float[3];

    //This timer is used to record the values of sensors for a period of time.
    private Timer SensorTimer=new Timer();


    //setting constant values for specific formulae
    boolean initialGyrostate=true;
    final float alpha= (float) 0.8;
    private static final float NS2S = 1.0f / 1000000000.0f;
    public static final float EPSILON = 0.000000001f;
    public static final float FILTER_COEFFICIENT = 0.98f;
    private float timestamp;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //filling the gyro orientation with 0.0 float values and oreintation matrix with identity
        // matrix values
        Arrays.fill(gyroorientationvalues,0.0f);

        for(int i=0;i<9;i++){
            if(i%4==0){
                gyroinitialmatrix[i]=1.0f;
            }
            else {
                gyroinitialmatrix[i]=0.0f;
            }
        }

        //locking the orientation of the phone to portrait so it doesn't
        // turn in all sorts of ways when rotating the device.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //UI VALUES
        z_azimuth=(EditText) findViewById(R.id.editTz);
        x_pitch=(EditText) findViewById(R.id.editTx);
        y_roll=(EditText) findViewById(R.id.editTy);
        resultbutton=(Button) findViewById(R.id.orientbutton);
        resultbutton.setOnClickListener(this);

        //Sensor Manager and Sensors
        sensor_manager=(SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer=sensor_manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope=sensor_manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        magnetometer=sensor_manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.orientbutton:
                //the listeners should be registered on click
                sensor_manager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_FASTEST);
                sensor_manager.registerListener(this,magnetometer,SensorManager.SENSOR_DELAY_FASTEST);
                sensor_manager.registerListener(this,gyroscope,SensorManager.SENSOR_DELAY_FASTEST);

                //the timer will be implemented here as soon as the button is clicked
                // and the data for 25 seconds will be collected
                SensorTimer.scheduleAtFixedRate(new calculateSensorFusionOrientationTask(),1000,20);
                break;
            }
        }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            //we are trying to remove the effect of gravity from acceleration
            //so that we can get the true acceleration values.
            gravitycords[0]=alpha * gravitycords[0] + (1 - alpha) * event.values[0];
            gravitycords[1]=alpha * gravitycords[1] + (1 - alpha) * event.values[1];
            gravitycords[2]=alpha * gravitycords[2] + (1 - alpha) * event.values[2];

            acclcords[0] = event.values[0] - gravitycords[0];
            acclcords[1] = event.values[1] - gravitycords[1];
            acclcords[2] = event.values[2] - gravitycords[2];
            calculateACMOrientation();
        }

        if(event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
            //magnetometer values are copied into magcords
            magcords=event.values.clone();
        }

        if(event.sensor.getType() == Sensor.TYPE_GYROSCOPE){
            //we cannot consider the values from the gyroscope directly
            //we will utilize this function to perform the necessary calculations
            CalculateGyroOrientation(event);
        }

    }

    public void calculateACMOrientation() {
        boolean acmrotationcheck = SensorManager.getRotationMatrix(acmrotationMatrix, null, acclcords, magcords);
        if (acmrotationcheck) {
            SensorManager.getOrientation(acmrotationMatrix, acmorientationValues);
        }
    }

    public void CalculateGyroOrientation(SensorEvent event) {
        if(acmorientationValues==null){
            // if there are no accelerometer and magnetometer values present
            // we simply return so that those values can be calculated first
            return;
        }

        if(initialGyrostate){
            // the initial gyroscope matrix and the rotation matrix from accelerometer
            // and magnetometer are multiplied and the bool value is set to false
            gyroinitialmatrix = matrixMultiplication(gyroinitialmatrix, acmrotationMatrix);
            initialGyrostate = false;
        }

        if(timestamp!=0){
            final float dT = (event.timestamp - timestamp) * NS2S;
            //values from the data collected by gyroscope sensor
            gyrocords=event.values.clone();

            float gyromagnitude= (float) Math.sqrt(gyrocords[0]*gyrocords[0] + gyrocords[1]*gyrocords[1] + gyrocords[2]*gyrocords[2]);
            if(gyromagnitude>EPSILON){
                //normalizing the data if the values are big enough to get the axis
                gyrocords[0]/=gyromagnitude;
                gyrocords[1]/=gyromagnitude;
                gyrocords[2]/=gyromagnitude;
            }

            //delta rotation vector is calculated by integrating the output from the gyroscope
            // before calculating the rotation matrix from these values.
            float halfAngleOfRotation=gyromagnitude*dT/2;
            deltaRotationVector[0]= (float) (Math.sin(halfAngleOfRotation)*gyrocords[0]);
            deltaRotationVector[1]= (float) (Math.sin(halfAngleOfRotation)*gyrocords[1]);
            deltaRotationVector[2]= (float) (Math.sin(halfAngleOfRotation)*gyrocords[2]);
            deltaRotationVector[3]= (float) (Math.cos(halfAngleOfRotation));
        }

        timestamp=event.timestamp;
        float[] deltaRotationMatrix = new float[9];
        SensorManager.getRotationMatrixFromVector(deltaRotationMatrix, deltaRotationVector);

        //gyroinitial matix is multiplied with delta rotation matrix to get the updated matrix
        //from which the orientation values are calculated.
        gyroinitialmatrix=matrixMultiplication(gyroinitialmatrix,deltaRotationMatrix);
        SensorManager.getOrientation(gyroinitialmatrix,gyroorientationvalues);
    }

    private float[] getRotationMatrixFromOrientation(float[] o) {
        float[] xMatrix = new float[9];
        float[] yMatrix = new float[9];
        float[] zMatrix = new float[9];

        float sinX = (float)Math.sin(o[1]);
        float sinY = (float)Math.sin(o[2]);
        float sinZ = (float)Math.sin(o[0]);
        float cosX = (float)Math.cos(o[1]);
        float cosY = (float)Math.cos(o[2]);
        float cosZ = (float)Math.cos(o[0]);

        // rotation about x, y and z axis
        xMatrix[0] = 1.0f;          yMatrix[0] = cosY;          zMatrix[0] = cosZ;
        xMatrix[1] = 0.0f;          yMatrix[1] = 0.0f;          zMatrix[1] = sinZ;
        xMatrix[2] = 0.0f;          yMatrix[2] = sinY;          zMatrix[2] = 0.0f;
        xMatrix[3] = 0.0f;          yMatrix[3] = 0.0f;          zMatrix[3] = -sinZ;
        xMatrix[4] = cosX;          yMatrix[4] = 1.0f;          zMatrix[4] = cosZ;
        xMatrix[5] = sinX;          yMatrix[5] = 0.0f;          zMatrix[5] = 0.0f;
        xMatrix[6] = 0.0f;          yMatrix[6] = -sinY;         zMatrix[6] = 0.0f;
        xMatrix[7] = -sinX;         yMatrix[7] = 0.0f;          zMatrix[7] = 0.0f;
        xMatrix[8] = cosX;          yMatrix[8] = cosY;          zMatrix[8] = 1.0f;

        // Resulting rotation matrix from three axes rotation matrices
        float[] finalRotationMatrix = matrixMultiplication(xMatrix, yMatrix);
        finalRotationMatrix = matrixMultiplication(zMatrix, finalRotationMatrix);
        return finalRotationMatrix;
    }

    private float[] matrixMultiplication(float[] A, float[] B) {
        float[] finalMatrix = new float[9];
        finalMatrix[0] = A[0] * B[0] + A[1] * B[3] + A[2] * B[6];
        finalMatrix[1] = A[0] * B[1] + A[1] * B[4] + A[2] * B[7];
        finalMatrix[2] = A[0] * B[2] + A[1] * B[5] + A[2] * B[8];
        finalMatrix[3] = A[3] * B[0] + A[4] * B[3] + A[5] * B[6];
        finalMatrix[4] = A[3] * B[1] + A[4] * B[4] + A[5] * B[7];
        finalMatrix[5] = A[3] * B[2] + A[4] * B[5] + A[5] * B[8];
        finalMatrix[6] = A[6] * B[0] + A[7] * B[3] + A[8] * B[6];
        finalMatrix[7] = A[6] * B[1] + A[7] * B[4] + A[8] * B[7];
        finalMatrix[8] = A[6] * B[2] + A[7] * B[5] + A[8] * B[8];
        return finalMatrix;
    }

    class calculateSensorFusionOrientationTask extends TimerTask {
        @Override
        public void run() {
            for (int i = 0; i < 3; i++) {
                if (gyroorientationvalues[0] < -0.5 * Math.PI && acmorientationValues[0] > 0.0) {
                    sensorFusionOrientation[i] = (float) (FILTER_COEFFICIENT * (gyroorientationvalues[i] + 2.0 * Math.PI) + (1.0f - FILTER_COEFFICIENT) * acmorientationValues[i]);
                    sensorFusionOrientation[i] -= (sensorFusionOrientation[i] > Math.PI) ? 2.0 * Math.PI : 0;
                } else if (acmorientationValues[i] < -0.5 * Math.PI && gyroorientationvalues[0] > 0.0) {
                    sensorFusionOrientation[i] = (float) (FILTER_COEFFICIENT * gyroorientationvalues[i] + (1.0f - FILTER_COEFFICIENT) * (acmorientationValues[i] + 2.0 * Math.PI));
                    sensorFusionOrientation[i] -= (sensorFusionOrientation[i] > Math.PI) ? 2.0 * Math.PI : 0;
                } else {
                    sensorFusionOrientation[i] = FILTER_COEFFICIENT * gyroorientationvalues[i] + (1.0f - FILTER_COEFFICIENT) * acmorientationValues[i];
                }
            }
            //gyro drift is eliminated by over writing the values of gyro matrix with that of
            //fused rotation matrix and gyro orientation values are overwritten as well.
            gyroinitialmatrix = getRotationMatrixFromOrientation(sensorFusionOrientation);
            gyroorientationvalues = sensorFusionOrientation.clone();

            OrientationTask mytask=new OrientationTask(sensorFusionOrientation[0],sensorFusionOrientation[1],sensorFusionOrientation[2]);
            myhandler.post(mytask);
        }
    }

    //A handler is used here to implement the User interface once all the above functions are
    //implemented so that there will not be any race condition
    private class OrientationTask implements Runnable{

        float ortx,orty,ortz;

        public OrientationTask(float orx,float ory,float orz){
            this.ortx= (float) (orx*180/(Math.PI));
            this.orty=(float) (ory*180/(Math.PI));
            this.ortz=(float) (orz*180/(Math.PI));
        }

        @Override
        public void run() {
            z_azimuth.setText(new Float(ortx).toString());
            x_pitch.setText(new Float(orty).toString());
            y_roll.setText(new Float(ortz).toString());
        }
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    //the listeners are also registered in onResume function because it is present in all
    //the paths present on the lifecycle of application
    // The listeners can be unregistered in the onPause and onStop.
    @Override
    protected void onResume() {
        super.onResume();
        sensor_manager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_FASTEST);
        sensor_manager.registerListener(this,magnetometer,SensorManager.SENSOR_DELAY_FASTEST);
        sensor_manager.registerListener(this,gyroscope,SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensor_manager.unregisterListener(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        sensor_manager.unregisterListener(this);

    }


}
