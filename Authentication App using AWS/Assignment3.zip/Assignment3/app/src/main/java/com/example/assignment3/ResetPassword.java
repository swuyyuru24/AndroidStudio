package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class ResetPassword extends AppCompatActivity implements View.OnClickListener{

    private CardView resetview,setview,confirmview;
    private ImageView goback;
    private Button resetbutton,setbutton;
    private EditText reset_username,set_newpassword,set_newcode;

    private final static String API_RESETPASSWORD="https://9h5q3bc4x3.execute-api.us-east-2.amazonaws.com/prod/user/resetpassword";
    private final static String API_CONFIRMPASSWORD="https://9h5q3bc4x3.execute-api.us-east-2.amazonaws.com/prod/user/confirmnewpassword";


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        resetview=(CardView) findViewById(R.id.ResetPasswordView);
        setview=(CardView) findViewById(R.id.SetPasswordView);
        confirmview=(CardView) findViewById(R.id.ConfirmView);


        goback=(ImageView) findViewById(R.id.back_button);
        resetbutton=(Button) findViewById(R.id.resetp_button);
        setbutton=(Button) findViewById(R.id.setp_button);
        reset_username=(EditText) findViewById(R.id.resetp_username);
        set_newpassword=(EditText) findViewById(R.id.setp_password);
        set_newcode=(EditText) findViewById(R.id.setp_code);

        goback.setOnClickListener(this);
        resetbutton.setOnClickListener(this);
        setbutton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_button:
                startActivity(new Intent(ResetPassword.this,LoginActivity.class));
                finish();
                break;

            case R.id.resetp_button:
                setParametersforReset();
                break;

            case R.id.setp_button:
                setParametersforSet();
                break;

        }
    }

    private void setParametersforReset() {
        String username_r=reset_username.getText().toString();
        String[] parameters=new String[2];

        parameters[0]=username_r;
        parameters[1]=API_RESETPASSWORD;
        WebService temp = new WebService();
        temp.execute(parameters);

    }

    private void setParametersforSet() {
        String username_r=reset_username.getText().toString();
        String password_r=set_newpassword.getText().toString();
        String code_r=set_newcode.getText().toString();

        String[] parameters=new String[4];

        parameters[0]=username_r;
        parameters[1]=code_r;
        parameters[2]=password_r;
        parameters[3]=API_CONFIRMPASSWORD;
        WebService1 temp2 = new WebService1();
        temp2.execute(parameters);

    }

    class WebService extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            try {
                String username=strings[0];
                String apiurl= strings[1];
                JSONObject json = new JSONObject();
                json.put("username",username);
                String jsonstring= json.toString();
                URL url=new URL(apiurl);
                HttpURLConnection urlConnection= (HttpURLConnection) url.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type","application/json");

                BufferedWriter writer=new BufferedWriter(new OutputStreamWriter
                        (urlConnection.getOutputStream(),"utf-8"));

                writer.write(jsonstring);
                writer.flush();
                writer.close();

                if(urlConnection.getResponseCode()==200){
                    BufferedReader bread=new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    String temp,responseString="";
                    while ((temp =bread.readLine())!=null){
                        responseString+=temp;
                    }
                    Log.d("WebService", "Response String: " + responseString);
                    JSONObject readobj= new JSONObject(responseString);
                    String message=readobj.getString("message");
                    return message;
                }
                else{
                    Log.d("WebService", "Response Code: " + urlConnection.getResponseCode());
                }

            }
            catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null && result.equals("Code Sent")) {
                Toast.makeText(getApplicationContext(), "Code has been sent", Toast.LENGTH_SHORT).show();
                resetview.setVisibility(View.GONE);
                setview.setVisibility(View.VISIBLE);
            }
        }
    }

    class WebService1 extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            try {
                String username=strings[0];
                String code=strings[1];
                String password=strings[2];
                String apiurl= strings[3];
                JSONObject json = new JSONObject();
                json.put("username",username);
                json.put("code",code);
                json.put("password",password);

                String jsonstring= json.toString();
                URL url=new URL(apiurl);
                HttpURLConnection urlConnection= (HttpURLConnection) url.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type","application/json");

                BufferedWriter writer=new BufferedWriter(new OutputStreamWriter
                        (urlConnection.getOutputStream(),"utf-8"));

                writer.write(jsonstring);
                writer.flush();
                writer.close();

                if(urlConnection.getResponseCode()==200){
                    BufferedReader bread=new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    String temp,responseString="";
                    while ((temp =bread.readLine())!=null){
                        responseString+=temp;
                    }
                    Log.d("WebService", "Response String: " + responseString);
                    JSONObject readobj= new JSONObject(responseString);
                    String message=readobj.getString("message");
                    return message;
                }
                else{
                    Log.d("WebService", "Response Code: " + urlConnection.getResponseCode());
                }

            }
            catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null && result.equals("Password Set")) {
                Toast.makeText(getApplicationContext(), "Password Confirmed", Toast.LENGTH_SHORT).show();
                setview.setVisibility(View.GONE);
                confirmview.setVisibility(View.VISIBLE);
            }
        }
    }
}