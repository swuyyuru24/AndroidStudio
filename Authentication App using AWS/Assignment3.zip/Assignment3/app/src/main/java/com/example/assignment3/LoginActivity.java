package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText username,password;
    private Button login;
    private TextView reset_password_text,register_text;

    private static final String API_SIGNIN= "https://9h5q3bc4x3.execute-api.us-east-2.amazonaws.com/prod/user/signin";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username= (EditText) findViewById(R.id.login_username);
        password=(EditText) findViewById(R.id.login_password);
        login=(Button) findViewById(R.id.login_button);
        reset_password_text=(TextView) findViewById(R.id.ForgotPasswordText);
        register_text=(TextView) findViewById(R.id.SignUpRedirectText);

        login.setOnClickListener(this);
        reset_password_text.setOnClickListener(this);
        register_text.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login_button:
                String username_r=username.getText().toString();
                String password_r=password.getText().toString();

                String[] parameters=new String[3];

                parameters[0]=username_r;
                parameters[1]=password_r;
                parameters[2]=API_SIGNIN;
                WebService temp = new WebService();
                temp.execute(parameters);
                break;

            case R.id.ForgotPasswordText:
                startActivity(new Intent(LoginActivity.this,ResetPassword.class));
                finish();
                break;

            case R.id.SignUpRedirectText:
                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
                finish();
                break;
        }
    }

    class WebService extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            try {
                String username=strings[0];
                String password=strings[1];
                String apiurl= strings[2];
                JSONObject json = new JSONObject();
                json.put("username",username);
                json.put("password",password);
                String jsonstring= json.toString();
                URL url=new URL(apiurl);
                HttpURLConnection urlConnection= (HttpURLConnection) url.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type","application/json");

                BufferedWriter writer=new BufferedWriter(new OutputStreamWriter
                        (urlConnection.getOutputStream(),"utf-8"));

                writer.write(jsonstring);
                writer.flush();
                writer.close();

                if(urlConnection.getResponseCode()==200){
                    BufferedReader bread=new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    String temp,responseString="";
                    while ((temp =bread.readLine())!=null){
                        responseString+=temp;
                    }
                    Log.d("WebService", "Response String: " + responseString);
                    JSONObject readobj= new JSONObject(responseString);
                    String message=readobj.getString("message");
                    return message;
                }
                else{
                    Log.d("WebService", "Response Code: " + urlConnection.getResponseCode());
                }

            }
            catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null && result.equals("Login Success")) {
                Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                Intent intent =new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            else{
                Toast.makeText(getApplicationContext(), "Incorrect username or password", Toast.LENGTH_SHORT).show();
            }
        }
    }



}