package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConfirmRegistration extends AppCompatActivity implements View.OnClickListener {

    private String username_reg;
    private TextView IntroLine, logintext;
    private EditText code;
    private Button confirm;

    private static final String API_SIGNIN = "https://9h5q3bc4x3.execute-api.us-east-2.amazonaws.com/prod/user/confirmsignup";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_registration);

        username_reg = getIntent().getStringExtra("username");
        IntroLine = (TextView) findViewById(R.id.IntroLine);
        IntroLine.setText("Hello " + username_reg + ", please enter the code sent to your email to confirm your registration");

        code = (EditText) findViewById(R.id.confirmsignup_code);
        logintext = (TextView) findViewById(R.id.LoginContinueText);
        confirm = (Button) findViewById(R.id.confirmsignup_button);

        logintext.setOnClickListener(this);
        confirm.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.confirmsignup_button:
                String code_r = code.getText().toString();
                String[] parameters = new String[3];

                parameters[0] = username_reg;
                parameters[1] = code_r;
                parameters[2] = API_SIGNIN;
                WebService temp = new WebService();
                temp.execute(parameters);
                break;

            case R.id.LoginContinueText:
                startActivity(new Intent(ConfirmRegistration.this, LoginActivity.class));
                finish();
                break;
        }

    }

    private class WebService extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            try {
                String username=strings[0];
                String code=strings[1];
                String apiurl= strings[2];
                JSONObject json = new JSONObject();
                json.put("username",username);
                json.put("code",code);
                String jsonstring= json.toString();
                URL url=new URL(apiurl);
                HttpURLConnection urlConnection= (HttpURLConnection) url.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type","application/json");

                BufferedWriter writer=new BufferedWriter(new OutputStreamWriter
                        (urlConnection.getOutputStream(),"utf-8"));

                writer.write(jsonstring);
                writer.flush();
                writer.close();

                if(urlConnection.getResponseCode()==200){
                    BufferedReader bread=new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    String temp,responseString="";
                    while ((temp =bread.readLine())!=null){
                        responseString+=temp;
                    }
                    Log.d("WebService", "Response String: " + responseString);
                    JSONObject readobj= new JSONObject(responseString);
                    String message=readobj.getString("message");
                    return message;
                }
                else{
                    Log.d("WebService", "Response Code: " + urlConnection.getResponseCode());
                }

            }
            catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            if (result != null && result.equals("Success in Confirmation")) {
                Toast.makeText(getApplicationContext(), "Confirmation Successful", Toast.LENGTH_SHORT).show();
                logintext.setVisibility(View.VISIBLE);

            }
        }
    }
}