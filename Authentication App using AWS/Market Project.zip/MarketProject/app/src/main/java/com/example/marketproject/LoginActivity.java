package com.example.marketproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import com.example.marketproject.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    ActivityLoginBinding binding;
    private ProgressDialog pgdg;
    private FirebaseAuth fbauth1;
    private String email,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        fbauth1=FirebaseAuth.getInstance();
        pgdg= new ProgressDialog(this);
        pgdg.setTitle("Please wait while we log you in..");
        pgdg.setCanceledOnTouchOutside(false);



        binding.forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,ForgotPassword.class));
            }
        });

        binding.loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Checkdata();
            }
        });

        binding.SignupRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
            }
        });
    }

    private void Checkdata() {
        email=binding.loginemail.getText().toString().trim();
        password=binding.loginpassword.getText().toString().trim();


        if (password.isEmpty()) {
            binding.loginpassword.setError("Password Required");
            binding.loginpassword.requestFocus();
        } else if (email.isEmpty()) {
            binding.loginemail.setError("Email Required");
            binding.loginemail.requestFocus();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.loginemail.setError("Invalid Email Id");
            binding.loginemail.requestFocus();
        } else {
            loginuser();
        }
    }

    private void loginuser() {
        pgdg.setMessage("Logging in");
        pgdg.show();

        fbauth1.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        pgdg.dismiss();

                        startActivity(new Intent(LoginActivity.this,MainActivity.class));
                        finishAffinity();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "Failure of login:"+e.getMessage(), Toast.LENGTH_SHORT).show();
                        pgdg.dismiss();
                    }
                });

    }
}