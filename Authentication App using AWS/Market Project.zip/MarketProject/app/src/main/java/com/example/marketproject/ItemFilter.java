package com.example.marketproject;

import android.widget.Filter;

import java.util.ArrayList;

public class ItemFilter extends Filter {

    private ItemAdapter adapter;
    private ArrayList<ItemModel> filtered_items;

    public ItemFilter(ItemAdapter adapter, ArrayList<ItemModel> filtered_items) {
        this.adapter = adapter;
        this.filtered_items = filtered_items;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results= new FilterResults();
        if ( constraint!=null && constraint.length()>0){
            constraint = constraint.toString().toUpperCase();

            ArrayList<ItemModel> filtereditem_model = new ArrayList<>();

            for (int i=0;i< filtered_items.size();i++){
                if(filtered_items.get(i).getBrand().toUpperCase().contains(constraint) ||
                        filtered_items.get(i).getCategory().toUpperCase().contains(constraint) ||
                        filtered_items.get(i).getCondition().toUpperCase().contains(constraint) ||
                        filtered_items.get(i).getTitle().toUpperCase().contains(constraint)
                ){
                    filtereditem_model.add(filtered_items.get(i));
                }
            }
            results.count=filtereditem_model.size();
            results.values=filtereditem_model;
        }
        else{
            results.count=filtered_items.size();
            results.values=filtered_items;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {

        adapter.item_arraylist=(ArrayList<ItemModel>) results.values;
        adapter.notifyDataSetChanged();
    }
}
