package com.example.marketproject;


import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.marketproject.databinding.PickedImagesViewBinding;

import java.util.ArrayList;

public class PickedImagesAdapter extends RecyclerView.Adapter< PickedImagesAdapter.PickedImagesHolder> {
    private PickedImagesViewBinding binding;
    private Context context;
    private ArrayList<PickedImageModel> imagepick_arrayList;

    public PickedImagesAdapter(Context context, ArrayList<PickedImageModel> imagepick_arrayList){
        this.context= context;
        this.imagepick_arrayList = imagepick_arrayList;
    }

    @NonNull
    @Override
    public PickedImagesHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         binding= PickedImagesViewBinding.inflate(LayoutInflater.from(context),parent,false);

         return new PickedImagesHolder(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull PickedImagesHolder holder, @SuppressLint("RecyclerView") int position) {
        PickedImageModel model= imagepick_arrayList.get(position);

        Uri image_uri=model.getUri_image();

        try{
            Glide.with(context)
                    .load(image_uri)
                    .placeholder(R.drawable.image_icon)
                    .into(holder.selectedImageView);
        }
        catch (Exception e){
            Toast.makeText(context, "Error:"+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        holder.CloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imagepick_arrayList.remove(model);
                notifyItemRemoved(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return imagepick_arrayList.size();
    }


    class PickedImagesHolder extends RecyclerView.ViewHolder{
        ImageView selectedImageView;
        ImageButton CloseButton;

        private PickedImagesHolder(@NonNull View itemView){
            super(itemView);

            selectedImageView= binding.selectedimage;
            CloseButton=binding.cancelbutton;
        }

    }
}
