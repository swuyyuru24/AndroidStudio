package com.example.marketproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.marketproject.databinding.FragmentHomeBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HomeFragment extends Fragment {


    private FragmentHomeBinding binding;
    private Context mContext;

    private ArrayList<ItemModel> item_AList;
    private ItemAdapter item_adapter;
    private SharedPreferences location_sp;
    @Override
    public void onAttach(@NonNull Context context) {
        mContext=context;
        super.onAttach(context);
    }

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding=FragmentHomeBinding.inflate(LayoutInflater.from(mContext),container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        loadCategories();
        load_items("ALL");

        binding.SearchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                try {
                    String query= s.toString();
                    item_adapter.getFilter().filter(query);

                }
                catch (Exception e){

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        item_adapter = new ItemAdapter(mContext, item_AList);
        binding.itemsView.setAdapter(item_adapter);
    }



    private void loadCategories() {
        ArrayList<CategoryModel> category_ArrayList=new ArrayList<>();

        CategoryModel allcategory_Model= new CategoryModel("ALL", R.drawable.category_icon);

        category_ArrayList.add(allcategory_Model);

        for(int i=0;i<custom.categories.length;i++){
            CategoryModel cmodel= new CategoryModel(custom.categories[i],custom.categoryIcons[i]);

            category_ArrayList.add(cmodel);
        }

        CategoryAdapter category_Adapter_= new CategoryAdapter(mContext, category_ArrayList, new CategoryListener() {
            @Override
            public void OnClickCategory(CategoryModel model) {
                load_items(model.getCategory());
            }
        });

        binding.CategoryView.setAdapter(category_Adapter_);
    }

    private void load_items(String Category){
        item_AList=new ArrayList<>();

        DatabaseReference dbref= FirebaseDatabase.getInstance().getReference("Items");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                item_AList.clear();
                for (DataSnapshot ds:snapshot.getChildren()){
                    ItemModel item_model=ds.getValue(ItemModel.class);

                    if("ALL".equals(Category)) {
                        item_AList.add(item_model);
                    }
                    else if(item_model.getCategory().equals(Category)){
                        item_AList.add(item_model);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}