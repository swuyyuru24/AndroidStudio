package com.example.marketproject;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.marketproject.databinding.CategoryhzLayoutBinding;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.Random;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryHolder>{

    private CategoryhzLayoutBinding binding;
    private Context mcontext;
    private ArrayList<CategoryModel> Category_AL;
    private CategoryListener category_listener;

    public CategoryAdapter(Context mcontext, ArrayList<CategoryModel> category_AL, CategoryListener categorylistener) {
        this.mcontext = mcontext;
        Category_AL = category_AL;
        category_listener = categorylistener;
    }

    @NonNull
    @Override
    public CategoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding=CategoryhzLayoutBinding.inflate(LayoutInflater.from(mcontext),parent,false);


        return new CategoryHolder(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryHolder holder, int position) {

        CategoryModel categModel=Category_AL.get(position);
        String category=categModel.getCategory();
        int icon=categModel.getIcon();

        Random random=new Random();
        int color= Color.argb(255,random.nextInt(255),random.nextInt(255),random.nextInt(255));

        holder.category_title.setText(category);
        holder.category_icon.setImageResource(icon);
        holder.category_icon.setBackgroundColor(color);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category_listener.OnClickCategory(categModel);
            }
        });


    }

    @Override
    public int getItemCount() {
        return Category_AL.size();
    }

    class CategoryHolder extends RecyclerView.ViewHolder{

        ShapeableImageView category_icon;
        TextView category_title;
        public CategoryHolder(@NonNull View itemView) {
            super(itemView);

            category_icon=binding.categoryIcon;
            category_title=binding.categoryTitle;
        }
    }
}
