package com.example.marketproject;

import android.content.Context;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.marketproject.databinding.ItemsColumnBinding;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.itemHolder> implements Filterable {
    private Context m_context;
    private FirebaseAuth fbauth_item;
    public ArrayList<ItemModel> item_arraylist;
    private ArrayList<ItemModel> filtered_list;

    private ItemFilter filter;
    private ItemsColumnBinding binding;

    public ItemAdapter(Context m_context, ArrayList<ItemModel> item_arraylist) {
        this.m_context = m_context;
        this.item_arraylist = item_arraylist;
        this.filtered_list=item_arraylist;

        fbauth_item= FirebaseAuth.getInstance();
    }

    @NonNull
    @Override
    public itemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding= ItemsColumnBinding.inflate(LayoutInflater.from(m_context),parent,false);
        return new itemHolder(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull itemHolder holder, int position) {

        ItemModel item_Model= item_arraylist.get(position);
        String title=item_Model.getTitle();
        String description=item_Model.getDescription();
        String place=item_Model.getPlace();
        String condition=item_Model.getCondition();
        String status=item_Model.getStatus();
        String price=item_Model.getPrice();

        String timestamp = item_Model.getTimestamp();
        long timeInMillis = 0;

        if (timestamp != null && !timestamp.isEmpty()) {
            try {
                timeInMillis = Long.parseLong(timestamp);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }


        Calendar calendar=Calendar.getInstance(Locale.ENGLISH);
        calendar.setTimeInMillis(timeInMillis);

        String formatted_date= DateFormat.format("dd/mm/yyyy",calendar).toString();

        loadItemFirstImage(item_Model,holder);

        holder.title_input.setText(title);
        holder.description_input.setText(description);
        holder.place_input.setText(place);
        holder.condition_input.setText(condition);
        holder.status_input.setText(status);
        holder.time_input.setText(formatted_date);


    }

    private void loadItemFirstImage(ItemModel item_model, itemHolder holder) {

        String item_id = item_model.getId();
        DatabaseReference item_ref= FirebaseDatabase.getInstance().getReference("Items");
        item_ref.child(item_id).child("Images").limitToFirst(1);
        item_ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot ds:snapshot.getChildren()){
//                           String item_id = ds.getKey();
                            String image_url=""+ds.child("imageUrl").getValue();
//                            DatabaseReference itemImagesRef = item_ref.child(item_id).child("Images");
//                            Query query = itemImagesRef.limitToFirst(1);
                            try{
                                Glide.with(m_context)
                                        .load(image_url)
                                        .placeholder(R.drawable.image_icon)
                                        .into(holder.shapeable_ImageView);
                            }
                            catch(Exception e){

                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    @Override
    public int getItemCount() {
        return item_arraylist.size();
    }

    @Override
    public Filter getFilter() {

        if(filter==null){
            filter= new ItemFilter(this,filtered_list);
        }
        return filter;
    }

    class itemHolder extends RecyclerView.ViewHolder{
        ShapeableImageView shapeable_ImageView;
        TextView title_input,description_input,place_input;
        TextView condition_input,status_input,price_input,time_input;

        public itemHolder(@NonNull View itemView) {
            super(itemView);

            title_input=binding.itemTitle;
            description_input=binding.itemDescription;
            place_input=binding.itemPlace;
            condition_input=binding.itemCondition;
            status_input=binding.itemStatus;
            price_input=binding.itemPrice;
            time_input=binding.itemTimestamp;

        }
    }
}
