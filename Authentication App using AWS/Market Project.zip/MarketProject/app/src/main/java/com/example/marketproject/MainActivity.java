package com.example.marketproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.marketproject.databinding.ActivityMainBinding;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener {

    private ActivityMainBinding binding;
    private FirebaseAuth fbauth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        FirebaseApp.initializeApp(this);
        fbauth = FirebaseAuth.getInstance();
        if (fbauth.getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            binding.bottomnavigbar.setOnItemSelectedListener(this);
            showHomeFragment();
        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId=item.getItemId();

        if(itemId== R.id.menu_home_icon){
            if(fbauth.getCurrentUser()==null){
                Toast.makeText(getApplicationContext(), "Login to access", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,LoginActivity.class));
                return false;
            }
            else{
                showHomeFragment();
                return true;
            }
        }
        else if(itemId==R.id.menu_add_icon){
            if(fbauth.getCurrentUser()==null){
                Toast.makeText(getApplicationContext(), "Login to access", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,LoginActivity.class));
                return false;
            }
            else{
                showAddItemFragment();
                return true;
            }
        }
        else if(itemId==R.id.menu_search_icon){
            if(fbauth.getCurrentUser()==null){
                Toast.makeText(getApplicationContext(), "Login to access", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,LoginActivity.class));
                return false;
            }
            else{
                showSearchFragment();
                return true;
            }

        }
        else if (itemId==R.id.menu_myaccount_icon) {
            if(fbauth.getCurrentUser()==null){
                Toast.makeText(getApplicationContext(), "Login to access", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,LoginActivity.class));
                return false;
            }
            else{
                showProfileFragment();
                return true;
            }
        }
        else{
            return false;
        }
    }

    private void showHomeFragment() {
        binding.headertitle.setText("Home");
        HomeFragment fragment=new HomeFragment();
        FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(binding.chosenFragment.getId(), fragment, "HomeFragment");
        fragmentTransaction.commit();
    }
    private void showAddItemFragment() {
        startActivity(new Intent(MainActivity.this,AddNewActivity.class));
      //  binding.headertitle.setText("Add new Product");
       // AddItemFragment fragment=new AddItemFragment();
        //FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
        //fragmentTransaction.replace(binding.chosenFragment.getId(), fragment, "AddItemFragment");
        //fragmentTransaction.commit();

    }
    private void showSearchFragment() {
        binding.headertitle.setText("Search my products");
        SearchFragment fragment=new SearchFragment();
        FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(binding.chosenFragment.getId(), fragment, "SearchFragment");
        fragmentTransaction.commit();
    }
    private void showProfileFragment() {
        binding.headertitle.setText("Profile");
        ProfileFragment fragment=new ProfileFragment();
        FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(binding.chosenFragment.getId(), fragment, "ProfileFragment");
        fragmentTransaction.commit();
    }
}