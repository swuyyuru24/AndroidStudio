package com.example.marketproject;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.marketproject.databinding.ActivityAddNewBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AddNewActivity extends AppCompatActivity {

    private ActivityAddNewBinding binding;
    private FirebaseAuth fbauth_an;
    private ProgressDialog pdg_an;
    private Uri image_uri=null;
    private PickedImagesAdapter adapter;
    private ArrayList<PickedImageModel> pickedImageArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityAddNewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        pdg_an=new ProgressDialog(this);
        pdg_an.setTitle("Loading..");
        pdg_an.setCanceledOnTouchOutside(false);

        fbauth_an= FirebaseAuth.getInstance();

        ArrayAdapter<String> CategoriesAdapter=new ArrayAdapter<>(this,R.layout.category_product,custom.categories);
        binding.CategoryInput.setAdapter(CategoriesAdapter);

        ArrayAdapter<String> ConditionAdapter=new ArrayAdapter<>(this,R.layout.condition_product,custom.conditions);
        binding.ConditionInput.setAdapter(ConditionAdapter);
        
        pickedImageArrayList= new ArrayList<>();
        uploadImage();

        binding.anbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.additembutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Verifydata();
            }
        });

        binding.ImageSelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OptionstoPickImages();
            }
        });
    }

    private void uploadImage() {
        adapter=new PickedImagesAdapter(this, pickedImageArrayList);
        binding.AddImagesPanel.setAdapter(adapter);
    }

    private void OptionstoPickImages() {
        PopupMenu popimagemenu = new PopupMenu(this, binding.ImageSelectButton);

        popimagemenu.getMenu().add(Menu.NONE, 1, 1, "Camera");
        popimagemenu.getMenu().add(Menu.NONE, 2, 2, "Photos");

        popimagemenu.show();

        popimagemenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == 1) {
                    //Option For Camera

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

                        String CameraPermission[]=new String[]{Manifest.permission.CAMERA};
                        CameraPermissionRequest.launch(CameraPermission);

                    } else {
                        String CameraPermission[]=new String[]{android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        CameraPermissionRequest.launch(CameraPermission);
                    }
                }
                else if (item.getItemId() == 2) {
                    //Option For Gallery

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pickImagefromGallery();
                    }
                    else {
                        StoragePermissionRequest.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    }
                }
                return true;
            }
        });
    }

    private ActivityResultLauncher<String> StoragePermissionRequest= registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            new ActivityResultCallback<Boolean>() {
                @Override
                public void onActivityResult(Boolean result) {
                    if(result){
                        //Launch the gallery here
                        pickImagefromGallery();
                    }
                    else{
                        //Storage permission are not granted, display a toast message
                        Toast.makeText(AddNewActivity.this,"Storage Permission Denied",Toast.LENGTH_SHORT).show();
                    }


                }
            }
    );

    private void pickImagefromGallery() {
        Intent galleryintent= new Intent(Intent.ACTION_PICK);
        galleryintent.setType("image/*");
        LaunchGalleryActivityResult.launch(galleryintent);
    }

    private ActivityResultLauncher<String[]> CameraPermissionRequest= registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(),
            new ActivityResultCallback<Map<String, Boolean>>() {
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allgranted=true;
                    for (Boolean isgranted:result.values()){
                        allgranted= (allgranted && isgranted);
                    }
                    if (allgranted) {
                        //Launch the camera here
                        pickImagefromCamera();
                    } else {
                        //Camera permission are not granted, display a toast message
                        Toast.makeText(AddNewActivity.this, "Camera Permission Denied", Toast.LENGTH_SHORT).show();
                    }

                }
            }
    );

    private void pickImagefromCamera() {
        ContentValues cv=new ContentValues();
        cv.put(MediaStore.Images.Media.TITLE,"sample image");
        cv.put(MediaStore.Images.Media.DESCRIPTION,"sample description");

        image_uri= getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);

        Intent cameraintent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraintent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        LaunchCameraActivityResult.launch(cameraintent);
    }

    private final ActivityResultLauncher<Intent> LaunchGalleryActivityResult =registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode()== Activity.RESULT_OK){
                        Intent data= result.getData();

                        image_uri=data.getData();
                        String timestamp=""+ System.currentTimeMillis();

                        PickedImageModel pim=new PickedImageModel(timestamp, image_uri,null,false);
                        pickedImageArrayList.add(pim);
                        uploadImage();
                    }
                    else{
                        Toast.makeText(AddNewActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private final ActivityResultLauncher<Intent> LaunchCameraActivityResult =registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode()== Activity.RESULT_OK){
                        Intent data= result.getData();

                        image_uri=data.getData();
                        String timestamp=""+ System.currentTimeMillis();

                        PickedImageModel pim=new PickedImageModel(timestamp, image_uri,null,false);
                        pickedImageArrayList.add(pim);
                        uploadImage();
                    }
                    else{
                        Toast.makeText(AddNewActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private String title="",description="",place="",price="", brand="",category="", condition="";
    private void Verifydata(){
        title=binding.TitleInput.getText().toString().trim();
        description=binding.DescriptionInput.getText().toString().trim();
        place=binding.PlaceInput.getText().toString().trim();
        brand=binding.BrandInput.getText().toString().trim();
        category=binding.CategoryInput.getText().toString().trim();
        condition=binding.ConditionInput.getText().toString().trim();
        price=binding.PriceInput.getText().toString().trim();

        if(title.isEmpty()){
            binding.TitleInput.setError("Title Required");
            binding.TitleInput.requestFocus();
        }
        else if(description.isEmpty()){
            binding.DescriptionInput.setError("Title Required");
            binding.DescriptionInput.requestFocus();
        }
        else if(place.isEmpty()){
            binding.PlaceInput.setError(" Required");
            binding.PlaceInput.requestFocus();
        }
        else if(brand.isEmpty()){
            binding.BrandInput.setError("Title Required");
            binding.BrandInput.requestFocus();
        }
        else if(category.isEmpty()){
            binding.CategoryInput.setError("Title Required");
            binding.CategoryInput.requestFocus();
        }
        else if(condition.isEmpty()){
            binding.ConditionInput.setError("Title Required");
            binding.ConditionInput.requestFocus();
        }
        else if(title.isEmpty()){
            binding.TitleInput.setError("Title Required");
            binding.TitleInput.requestFocus();
        }
        else if(pickedImageArrayList.isEmpty()){
            Toast.makeText(this, "Choose atleast one image", Toast.LENGTH_SHORT).show();
        }
        else{
            AddnewItem();
        }

    }

    private void AddnewItem() {

        pdg_an.setMessage("Adding the new item..");
        pdg_an.show();

        String timestamp= String.valueOf(System.currentTimeMillis());
        DatabaseReference dbref_items= FirebaseDatabase.getInstance().getReference("Items");
        String key_id=dbref_items.push().getKey();

        HashMap<String,Object> items=new HashMap<>();
        items.put("KeyId",""+key_id);
        items.put("Uid",""+fbauth_an.getUid());
        items.put("Title",""+title);
        items.put("Description",""+description);
        items.put("Place",""+place);
        items.put("Brand",""+brand);
        items.put("Category",""+category);
        items.put("Condition",""+condition);
        items.put("Price",""+price);
        items.put("Timestamp",timestamp);
        items.put("Status",""+custom.Status_OWN);

        dbref_items.child(key_id)
                .setValue(items)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        uploadImagestoStorage(key_id);
                        Toast.makeText(AddNewActivity.this, "Item Successfully added", Toast.LENGTH_SHORT).show();
                        // Clear input values
                        binding.TitleInput.setText("");
                        binding.DescriptionInput.setText("");
                        binding.PlaceInput.setText("");
                        binding.BrandInput.setText("");
                        binding.CategoryInput.setText("");
                        binding.ConditionInput.setText("");
                        binding.PriceInput.setText("");

                        // Clear picked images
                        pickedImageArrayList.clear();
                        adapter.notifyDataSetChanged();


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddNewActivity.this, "Failed to store"+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void uploadImagestoStorage(String itemId) {
        for(int i=0;i<pickedImageArrayList.size();i++){
            PickedImageModel pim= pickedImageArrayList.get(i);

            String image_name=pim.getId();
            String filepathwithname="Items/"+image_name;

            int index_image=i+1;

            StorageReference storeimages= FirebaseStorage.getInstance().getReference(filepathwithname);

            storeimages.putFile(pim.getUri_image())
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {

                            double progress=(100.0 * snapshot.getBytesTransferred())/snapshot.getTotalByteCount();
                            String message="Uploading "+index_image + "of "+pickedImageArrayList.size() + " images\nProgress" + (int)progress+"%";

                            pdg_an.setMessage(message);
                            pdg_an.show();
                        }
                    })
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Task<Uri> uritask=taskSnapshot.getStorage().getDownloadUrl();

                            while (!uritask.isSuccessful());
                            Uri uploadedimage= uritask.getResult();

                            if (uritask.isSuccessful()){
                                HashMap<String, Object>  image_hm=new HashMap<>();
                                image_hm.put("id",""+pim.getId());
                                image_hm.put("imageUrl",""+uploadedimage);

                                DatabaseReference dbref_image= FirebaseDatabase.getInstance().getReference("Items");
                                dbref_image.child(itemId).child("Images")
                                        .child(image_name)
                                        .updateChildren(image_hm);
                            }

                            pdg_an.dismiss();

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(AddNewActivity.this, "Failure due to "+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
}