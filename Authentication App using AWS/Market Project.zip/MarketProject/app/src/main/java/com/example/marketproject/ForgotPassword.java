package com.example.marketproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import com.example.marketproject.databinding.ActivityForgotPasswordBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPassword extends AppCompatActivity {

    ActivityForgotPasswordBinding binding;

    private String email="";

    private FirebaseAuth fbauth_fg;
    private ProgressDialog pgdg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        pgdg= new ProgressDialog(this);
        pgdg.setTitle("Please wait..");
        pgdg.setCanceledOnTouchOutside(false);

        fbauth_fg=FirebaseAuth.getInstance();

        binding.fpbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.emailverification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(ForgotPassword.this,VerifyEmail.class));

            }
        });

        binding.resetbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VerifyEmail();
            }
        });

    }

    private void VerifyEmail(){
        email=binding.registeredemail.getText().toString().trim();

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            binding.registeredemail.setError("Invalid Email address");
        }
        else{
            SetPassword();
        }
    }

    private void SetPassword() {
        pgdg.setMessage("Sending Password reset link to email..");
        pgdg.show();

        fbauth_fg.sendPasswordResetEmail(email)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        pgdg.dismiss();
                        Toast.makeText(getApplicationContext(), "Link to reset password has been sent", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pgdg.dismiss();
                        Toast.makeText(getApplicationContext(), "Failed to send link:"+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }
}