package com.example.marketproject;

public class custom {


    public static final String  Status_OWN ="OWN";
    public static final String  Status_SOLD ="SOLD";
    public static final String  Status_DONATED ="DONATED";

    public static final String[] categories={
            "Electronics & Appliances",
            "Home Decor",
            "Books",
            "Furniture",
            "Clothing",
            "Beauty & Grooming",
            "Sports",
            "Footwear",
            "Accessories",
    };

    public static final int[] categoryIcons={
            R.drawable.electronics_icon,
            R.drawable.homedecor_icon,
            R.drawable.books_icon,
            R.drawable.furniture_icon,
            R.drawable.clothing_icon,
            R.drawable.beauty_icon,
            R.drawable.sports_icon,
            R.drawable.footwear_icon,
            R.drawable.accessories_icon
    };

    public static final String[] conditions={
            "New",
            "Used",
            "Worn-off"
    };

    }
