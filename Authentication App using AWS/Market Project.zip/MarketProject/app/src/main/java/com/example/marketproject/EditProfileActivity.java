package com.example.marketproject;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.marketproject.databinding.ActivityEditProfileBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class EditProfileActivity extends AppCompatActivity {

    private ActivityEditProfileBinding binding;
    private FirebaseAuth epfbauth;
    private ProgressDialog pdgep;
    private Uri imageuri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        pdgep = new ProgressDialog(this);
        pdgep.setTitle("Please wait...");
        pdgep.setCanceledOnTouchOutside(false);

        epfbauth = FirebaseAuth.getInstance();

        GetUserInformation();

        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.editprofileimagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImageforProfile();
            }
        });

        binding.updateprofileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VerifyData();
            }
        });

    }

    String name = "", username = "", phone = "", dob = "";

    private void VerifyData() {
        name = binding.editprofilename.getText().toString().trim();
        username = binding.editprofileusername.getText().toString().trim();
        phone = binding.editprofilePhone.getText().toString().trim();
        dob = binding.editprofileDOB.getText().toString().trim();

        if (imageuri == null) {
            newProfilePhotoupdate_Database(null);
        } else {
            SelectPhotofromStorage();
        }
    }

    private void SelectPhotofromStorage() {
        pdgep.setMessage("Image Uploading..");
        pdgep.show();

        String filepath = "UserImages/" + "profile" + epfbauth.getUid();

        StorageReference reference = FirebaseStorage.getInstance().getReference().child(filepath);
        reference.putFile(imageuri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Task<Uri> URI_task = taskSnapshot.getStorage().getDownloadUrl();
                        URI_task.addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                String ImageURL = uri.toString();
                                newProfilePhotoupdate_Database(ImageURL);
                            }
                        });
                    }
                })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                        double prog = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                        pdgep.setMessage("Profile photo uploading.." + (int) prog + "%");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pdgep.dismiss();
                        Toast.makeText(EditProfileActivity.this, "Failed to upload image", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void newProfilePhotoupdate_Database(String image_url) {
        pdgep.setMessage("Updating User Information");
        pdgep.show();

        HashMap<String, Object> userinfo = new HashMap<>();
        userinfo.put("Name", "" + name);
        userinfo.put("DOB", "" + dob);
        userinfo.put("PhoneNumber", "" + phone);
        userinfo.put("Username", "" + username);

        if (image_url != null) {
            userinfo.put("ProfileImage", "" + image_url);
        }

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Users");

        dbref.child(epfbauth.getUid())
                .updateChildren(userinfo)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        pdgep.dismiss();
                        Toast.makeText(EditProfileActivity.this, "Profile Updates", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pdgep.dismiss();
                        Toast.makeText(EditProfileActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void SelectImageforProfile() {
        PopupMenu imagemenu = new PopupMenu(this, binding.editprofileimagebutton);

        imagemenu.getMenu().add(Menu.NONE, 1, 1, "Camera");
        imagemenu.getMenu().add(Menu.NONE, 2, 2, "Photos");

        imagemenu.show();

        imagemenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == 1) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        requestCameraPermission.launch(new String[]{Manifest.permission.CAMERA});
                    } else {
                        requestCameraPermission.launch(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE});
                    }
                } else if (item.getItemId() == 2) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        SelectImagefromGallery();
                    } else {
                        requestphoneStoragePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    }
                }
                return false;
            }
        });
    }

    private ActivityResultLauncher<String[]> requestCameraPermission = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(),
            new ActivityResultCallback<Map<String, Boolean>>() {
                @Override
                public void onActivityResult(Map<String, Boolean> result) {
                    boolean allgranted = true;
                    for (Boolean isgranted : result.values()) {
                        allgranted = (allgranted && isgranted);
                    }

                    if (allgranted) {
                        Toast.makeText(EditProfileActivity.this, "Camera and Photos permissions granted", Toast.LENGTH_SHORT).show();
                        SelectImagefromCamera();
                    } else {
                        Toast.makeText(EditProfileActivity.this, "Camera or Photos permissions denied", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private ActivityResultLauncher<String> requestphoneStoragePermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            new ActivityResultCallback<Boolean>() {
                @Override
                public void onActivityResult(Boolean result) {
                    if (result) {
                        SelectImagefromGallery();
                    } else {
                        Toast.makeText(EditProfileActivity.this, "Phone Storage permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private void SelectImagefromCamera() {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.TITLE, "temp");
        cv.put(MediaStore.Images.Media.DESCRIPTION, "description");

        imageuri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageuri);
        cameraResultLauncher.launch(intent);
    }

    private ActivityResultLauncher<Intent> cameraResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Log.d("Image result", "Image Captured" + imageuri);

                        try {
                            Glide.with(EditProfileActivity.this)
                                    .load(imageuri)
                                    .placeholder(R.drawable.profile_icon)
                                    .into(binding.editprofileimage);
                        } catch (Exception e) {
                            Log.e("Image Uploaded", "Exception:" + e);
                        }
                    } else {
                        Toast.makeText(EditProfileActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private void SelectImagefromGallery() {
        Intent photointent = new Intent(Intent.ACTION_PICK);
        photointent.setType("image/*");
        galleryActivityResultLauncher.launch(photointent);
    }

    private ActivityResultLauncher<Intent> galleryActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent imagedata = result.getData();
                        imageuri = imagedata.getData();

                        Log.d("Image Result", "Image selected");
                        try {
                            Glide.with(EditProfileActivity.this)
                                    .load(imageuri)
                                    .placeholder(R.drawable.profile_icon)
                                    .into(binding.editprofileimage);
                        } catch (Exception e) {
                            Log.e("Image Result", "Result:" + e);
                        }
                    } else {
                        Toast.makeText(EditProfileActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private void GetUserInformation() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");

        reference.child(epfbauth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String name = "" + snapshot.child("Name").getValue();
                        String username = "" + snapshot.child("Username").getValue();
                        String email = "" + snapshot.child("Email").getValue();
                        String phone = "" + snapshot.child("PhoneNumber").getValue();
                        String dateofbirth = "" + snapshot.child("DOB").getValue();
                        String profilePhotoURL = "" + snapshot.child("ProfileImage").getValue();

                        binding.editprofilename.setText(name);
                        binding.editprofileusername.setText(username);
                        binding.editprofileEmail.setText(email);
                        binding.editprofilePhone.setText(phone);
                        binding.editprofileDOB.setText(dateofbirth);

                        try {
                            Glide.with(EditProfileActivity.this)
                                    .load(profilePhotoURL)
                                    .placeholder(R.drawable.profile_icon)
                                    .into(binding.editprofileimage);
                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(EditProfileActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
