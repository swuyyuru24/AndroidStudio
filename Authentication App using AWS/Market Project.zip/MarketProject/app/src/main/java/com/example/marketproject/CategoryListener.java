package com.example.marketproject;

public interface CategoryListener {
    void OnClickCategory(CategoryModel model);
}
