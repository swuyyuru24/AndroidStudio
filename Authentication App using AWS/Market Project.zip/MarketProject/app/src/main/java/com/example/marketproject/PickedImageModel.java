package com.example.marketproject;

import android.net.Uri;

public class PickedImageModel {

    String id="";
    Uri uri_image=null;
    String image_url=null;
    Boolean fromInternet=false;

    public PickedImageModel(String id, Uri uri_image, String image_url, Boolean fromInternet) {
        this.id = id;
        this.uri_image = uri_image;
        this.image_url = image_url;
        this.fromInternet = fromInternet;
    }

    public PickedImageModel(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Uri getUri_image() {
        return uri_image;
    }

    public void setUri_image(Uri uri_image) {
        this.uri_image = uri_image;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public Boolean getFromInternet() {
        return fromInternet;
    }

    public void setFromInternet(Boolean fromInternet) {
        this.fromInternet = fromInternet;
    }
}
