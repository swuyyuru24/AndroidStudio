package com.example.marketproject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Trace;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.marketproject.databinding.FragmentProfileBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ProfileFragment extends Fragment {



    private FragmentProfileBinding binding;
    private FirebaseAuth fbauth;
    private ProgressDialog pdg;
    private Context acontext;
    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        acontext=context;
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding= FragmentProfileBinding.inflate(LayoutInflater.from(acontext),container,false);

        // Inflate the layout for this fragment
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        pdg = new ProgressDialog(acontext);
        pdg.setTitle("Please Wait....");
        pdg.setCanceledOnTouchOutside(false);
        fbauth= FirebaseAuth.getInstance();

        GetUserInformation();
        binding.logoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fbauth.signOut();
                Toast.makeText(acontext, "You are logged out", Toast.LENGTH_LONG).show();
                startActivity(new Intent(acontext, MainActivity.class));
                getActivity().finishAffinity();
            }
        });

        binding.editProfilebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(acontext, EditProfileActivity.class));
            }
        });

        binding.ChangePasswordbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(acontext, ForgotPassword.class));

            }
        });

        binding.verifyProfilebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VerifyUser();
            }
        });

    }

    private void VerifyUser() {

        pdg.setMessage("Sending verification link..");
        pdg.show();
        fbauth.getCurrentUser().sendEmailVerification()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        pdg.dismiss();
                        Toast.makeText(acontext, "Verification link sent!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pdg.dismiss();
                        Toast.makeText(acontext, "Failed because"+e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });
    }

    private void GetUserInformation() {
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Users");

        reference.child(fbauth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String name=""+snapshot.child("Name").getValue();
                        String username=""+snapshot.child("Username").getValue();
                        String email=""+snapshot.child("Email").getValue();
                        String phone=""+snapshot.child("PhoneNumber").getValue();
                        String dateofbirth=""+snapshot.child("DOB").getValue();
                        String profilePhotoURL=""+snapshot.child("ProfileImage").getValue();


                        binding.profilename.setText(name);
                        binding.profileusername.setText(username);
                        binding.profileEmail.setText(email);
                        binding.profilePhone.setText(phone);
                        binding.profileDOB.setText(dateofbirth);
                        boolean isVerified=fbauth.getCurrentUser().isEmailVerified();
                        if(isVerified){
                            binding.profileVerified.setText("Yes");
                        }
                        else{
                            binding.profileVerified.setText("No");
                        }

                        try {
                            Glide.with(acontext)
                                    .load(profilePhotoURL)
                                    .placeholder(R.drawable.profile_icon)
                                    .into(binding.profileimage);

                        }
                        catch (Exception e){
                            Toast.makeText(acontext, "Exception:"+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }
}