package com.example.marketproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.tv.TvContract;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.marketproject.databinding.ActivityRegisterBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    private String name, username, email, password;

    ProgressDialog pdgdg1;
    private FirebaseAuth fbauth2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Log.d("DEBUG", "Binding successful");

        fbauth2=FirebaseAuth.getInstance();

        pdgdg1= new ProgressDialog(this);
        pdgdg1.setTitle("Registering...");
        pdgdg1.setCanceledOnTouchOutside(false);

        binding.LoginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                finishAffinity();
            }
        });

        binding.registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Checkdata();
            }
        });
    }

    private void Checkdata() {
        name = binding.registerName.getText().toString();
        password = binding.registerPassword.getText().toString();
        email = binding.registerEmail.getText().toString().trim();

        if (password.isEmpty()) {
            binding.registerPassword.setError("Password Required");
            binding.registerPassword.requestFocus();
        } else if (email.isEmpty()) {
            binding.registerEmail.setError("Email Required");
            binding.registerEmail.requestFocus();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.registerEmail.setError("Invalid Email Id");
            binding.registerEmail.requestFocus();
        } else if (name.isEmpty()) {
            binding.registerName.setError("Name Required");
            binding.registerName.requestFocus();
        } else {
            // Get the username value and check if it's empty or null
            EditText usernameEditText = binding.registerUsername;
            if (usernameEditText == null) {
                Toast.makeText(getApplicationContext(), "Username field is null", Toast.LENGTH_SHORT).show();
                return;
            }

            username = usernameEditText.getText().toString().trim();
            if (username.isEmpty()) {
                usernameEditText.setError("Username Required");
                usernameEditText.requestFocus();
            } else {
                registerUser();
            }
        }
    }


    private void registerUser() {
        pdgdg1.setMessage("Creating a new Account");
        pdgdg1.show();

        // Check if email and password are empty or null
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Email and password are required", Toast.LENGTH_SHORT).show();
            pdgdg1.dismiss();
            return;
        }

        fbauth2.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                        UserInformation();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "Failure of registration: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        pdgdg1.dismiss();
                    }
                });
    }


    private void UserInformation() {
        String currentuser_email=fbauth2.getCurrentUser().getEmail();
        String currentuser_UId=fbauth2.getCurrentUser().getUid();

        HashMap<String,Object> userdata=new HashMap<>();
        userdata.put("Name",name);
        userdata.put("Username",username);
        userdata.put("Email",currentuser_email);
        userdata.put("UId",currentuser_UId);
        userdata.put("ProfileImage","");
        userdata.put("PhoneNumber","");
        userdata.put("DOB","");
        userdata.put("Timestamp",System.currentTimeMillis());


        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
        ref.child(currentuser_UId)
                .setValue(userdata)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        pdgdg1.dismiss();
                        startActivity(new Intent(RegisterActivity.this,MainActivity.class));
                        finishAffinity();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pdgdg1.dismiss();
                        Toast.makeText(getApplicationContext(), "Failure of registration:"+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}