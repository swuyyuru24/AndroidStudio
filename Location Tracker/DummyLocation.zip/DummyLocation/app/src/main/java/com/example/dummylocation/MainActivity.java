package com.example.dummylocation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener, OnMapReadyCallback,SensorEventListener {

    TextView latitude_, longitude_, altitude_, accuracy_, speed_, sensor_, updates_, address_;
    Switch locationupdates, powerupdates;

    private GoogleMap gmap;
    private LocationManager location_manager;
    private LocationListener location_listener;


    private SensorManager sensor_Manager;
    private Sensor accelerometer;
    private SensorEventListener sensorlistener;

    private float acclcords[]=new float[3];
    private float gravitycords[]=new float[3];
    private float[] acrotationMatrix = new float[9];

    final float alpha= (float) 0.8;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        latitude_ = findViewById(R.id.latitude);
        longitude_ = findViewById(R.id.longitude);
        /*
        altitude_ = findViewById(R.id.altitude);
        accuracy_ = findViewById(R.id.accuracy);
        speed_ = findViewById(R.id.speed);
        sensor_ = findViewById(R.id.sensor);
        updates_ = findViewById(R.id.updates);
        address_ = findViewById(R.id.address);

        locationupdates = findViewById(R.id.swLocationupdates);
        powerupdates = findViewById(R.id.swPowerUpdates);

        */

        location_manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        location_manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);


    }
    @Override
    public void onLocationChanged(@NonNull Location location) {

        latitude_.setText("" + location.getLatitude());
        longitude_.setText( "" + location.getLongitude());

        double lati_= location.getLatitude();
        double longi_= location.getLongitude();
        Bundle bundle=new Bundle();
        bundle.putDouble("Latitude",lati_);
        bundle.putDouble("Longitude",longi_);

        Fragment mapFragment=new Fragment();
        mapFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(R.id.map_layout, mapFragment).commit();
        //mapFragment.getMapAsync(this);
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            //we are trying to remove the effect of gravity from acceleration
            //so that we can get the true acceleration values.
            gravitycords[0]=alpha * gravitycords[0] + (1 - alpha) * event.values[0];
            gravitycords[1]=alpha * gravitycords[1] + (1 - alpha) * event.values[1];
            gravitycords[2]=alpha * gravitycords[2] + (1 - alpha) * event.values[2];

            acclcords[0] = event.values[0] - gravitycords[0];
            acclcords[1] = event.values[1] - gravitycords[1];
            acclcords[2] = event.values[2] - gravitycords[2];

        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            location_manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, location_listener);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        location_manager.removeUpdates(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        location_manager.removeUpdates(this);
    }

    @Override
    public void onLocationChanged(@NonNull List<Location> locations) {
        LocationListener.super.onLocationChanged(locations);
    }

    @Override
    public void onFlushComplete(int requestCode) {
        LocationListener.super.onFlushComplete(requestCode);
    }


    @Override
    public void onProviderEnabled(@NonNull String provider) {
        LocationListener.super.onProviderEnabled(provider);
        Log.d("Latitude","enable");

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        LocationListener.super.onProviderDisabled(provider);
        Log.d("Latitude","disable");

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

    }



    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}